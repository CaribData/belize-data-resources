# Belize 'Messy' Datasets (Test Bundle)

Raw Excel/CSV files pulled from public sources to exercise ingest and cleaning.

See `_manifest.json` for file list and `_report.json` for structural hints (sheets, merged cells, etc.).
