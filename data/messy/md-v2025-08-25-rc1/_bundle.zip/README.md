# Belize 'Messy' Data Bundle

This ZIP contains intentionally messy public datasets to test ingest/clean pipelines.

## Included
- **SIB – Leading Causes of Death, 2021** — source: Statistical Institute of Belize — slug: `sib_health_death_causes_2021`
- **SIB – Secondary Education Statistics 2021/22** — source: Statistical Institute of Belize — slug: `sib_secondary_education_2021_22`
- **Central Bank – Monetary Survey (Banking System)** — source: Central Bank of Belize — slug: `cbb_monetary_survey`
- **Central Bank – GDP by Expenditure (Current Prices)** — source: Central Bank of Belize — slug: `cbb_gdp_by_expenditure_current`
- **Ministry of Agriculture – Production Stats 2003** — source: Ministry of Agriculture — slug: `moa_production_stats_2003`
- **SIB – Tourism Statistics (xlsx)** — source: Statistical Institute of Belize — slug: `sib_tourism_statistics`
- **Central Bank – Key Tourism Indicators (xlsx via page)** — source: Central Bank of Belize — slug: `cbb_key_tourism_indicators`

Each file is provided as-downloaded (“raw”). See `_manifest.json` and `_report.json` for details.
